export interface Iproduct{
    id:number,
    productname:string,
    productdescription:string,
    productprice:number,
    productquantity:number,
    productcategory:string,
    productimageurl:string
}

export interface IUser{
   id:number,
   name:string,
   email:string,
   contactNumber:string,
   address:string
}