import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {

  constructor(private http:HttpClient) { }



  getAllproduct(){
    return  this.http.get("https://localhost:7235/api/Admin/GetAllProduct");
  }

  deleteproductById(id:number){
    return this.http.delete(`https://localhost:7235/api/Admin/DelteProduct/${id}`);
  }
  addproduct(data:any){
   return this.http.post("https://localhost:7235/api/Admin/AddProduct",data);
  }

  getalluserInAdmin(){
    return   this.http.get("https://localhost:7235/api/Admin/GetAllUser");
  }

  deleteuserByIdInAdmin(id:number){
    return this.http.delete(`https://localhost:7235/api/Customer/Deletecustomer/${id}`);
  }

  registration(data:any){
   return this.http.post("https://localhost:7235/api/Customer/Register",data);
  }

  Addtocart(data:any){
    return  this.http.post("https://localhost:7235/api/Cart/Addtocart",data);

  }
}
