import { Component } from '@angular/core';
import { Iproduct } from '../../Model/Interface/Product';
import { AdminserviceService } from '../../Service/adminservice.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-customerhome',
  imports: [CommonModule],
  templateUrl: './customerhome.component.html',
  styleUrls: ['./customerhome.component.css'] 
})
export class CustomerhomeComponent {

  productlist: Iproduct[] = [];
  loggeduserid: any = null;
 
  
  constructor(private admin: AdminserviceService) {}
  
  ngOnInit(): void {
    this.getproduct();
    this.loggeduserid=JSON.parse(sessionStorage.getItem("key")||"null");
  
  }

  getproduct() {
    this.admin.getAllproduct().subscribe(
      (res: any) => {
        this.productlist = res;
      },
      (error: any) => {
        console.error('Error fetching products', error);
        alert(error.message);
      }
    );
  }

  
  AddToCart(id: number, totalPrice: number) {
   
   
    const quantity = 1;
    if(this.loggeduserid!=null){
    
      const formdata=new FormData();
      formdata.append("CustomerId",this.loggeduserid);
      formdata.append("ProductId",id.toString());
      formdata.append("Quantity",quantity.toString());
      formdata.append("Totalamount",totalPrice.toString());

      this.admin.Addtocart(formdata).subscribe((res:any)=>{

        alert(res.message);
        this.getproduct();
      },(error:any)=>{
        alert(error.message);
      })



    }
  }
}
