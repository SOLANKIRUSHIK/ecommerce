import { CommonModule, JsonPipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart',
  imports: [CommonModule],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent implements OnInit {

  cartlist: any[] = [];
  totleamount: number = 0;
  newQuantity: number = 1;
  http = inject(HttpClient);
  customerid: number = JSON.parse(sessionStorage.getItem("key") || "null");
  ngOnInit(): void {

    this.getallproductfromcart();
    this.gettotlemount();
  }



  getallproductfromcart() {

    if (this.customerid != null) {
      this.http.get("https://localhost:7235/api/Cart/getcartdata/" + this.customerid).subscribe((res: any) => {
        this.cartlist = res;
      }, (error: any) => {
        alert(error.message);
      })
    }
  }
  gettotlemount() {
    if (this.customerid != null) {
      this.http.get("https://localhost:7235/api/Cart/Gettotle/" + this.customerid).subscribe((res: any) => {
        this.totleamount = res;
      }, (error: any) => {
        alert(error.message);
      })
    }
  }

  removefromcart(id: number) {
    this.http.delete(`https://localhost:7235/api/Cart/removefromcard/${id}`).subscribe((result: any) => {
      alert(result.message);

      this.getallproductfromcart();
      this.gettotlemount();
    }, (error: any) => {

      alert(error.message);
    })
  }

  operationoncart(id: number, action: string) {



    var formdata = new FormData();
    formdata.append("Id", id.toString());
    formdata.append("Quantity", this.newQuantity.toString());
    formdata.append("Actiontype", action);


    this.http.post("https://localhost:7235/api/Cart/Operation", formdata).subscribe((res: any) => {
      alert(res.message);

      this.getallproductfromcart();
      this.gettotlemount();
    }, (error: any) => {
      alert(error.message);
    })


  }


  download() {
    window.location.href = `https://localhost:7235/api/Cart/generatepdf/${this.customerid}`;
  }


}
