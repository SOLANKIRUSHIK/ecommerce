import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AdminserviceService } from '../../Service/adminservice.service';
import { Iproduct } from '../../Model/Interface/Product';

@Component({
  selector: 'app-adminproduct',
  imports: [CommonModule],
  templateUrl: './adminproduct.component.html',
  styleUrl: './adminproduct.component.css'
})
export class AdminproductComponent implements OnInit {



  productlist:Iproduct[]=[];

  
constructor(private admin:AdminserviceService){

}


  ngOnInit(): void {
    this.getproduct();
  }

getproduct(){
 this.admin.getAllproduct().subscribe((res:any)=>{
    debugger;
    this.productlist=res;
  },(error: any) => {
    debugger;
    console.error('Error fetching products', error);
  alert(error.message);
  });
};




deleteProduct(id:number){
debugger;
this.admin.deleteproductById(id).subscribe((result:any)=>{
  alert(result.message);
  this.getproduct();
},(error:any)=>{

  alert(error.message);
})

}






}





