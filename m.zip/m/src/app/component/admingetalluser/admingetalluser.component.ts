import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit } from '@angular/core';
import { AdminserviceService } from '../../Service/adminservice.service';
import { IUser } from '../../Model/Interface/Product';

@Component({
  selector: 'app-admingetalluser',
  imports: [CommonModule],
  templateUrl: './admingetalluser.component.html',
  styleUrl: './admingetalluser.component.css'
})
export class AdmingetalluserComponent implements OnInit {


  userlist: IUser[] = [];

  constructor(private admin:AdminserviceService){

  }

  http = inject(HttpClient);

  ngOnInit(): void {
    this.getalluser();
  }


  getalluser() {
    this.admin.getalluserInAdmin().subscribe((res: any) => {
      this.userlist = res;
    }, (error: any) => {
      alert(error.message);
    })
  }

  deleteuser(id:number){
   this.admin.deleteuserByIdInAdmin(id).subscribe((res:any)=>{

      alert(res.message);
      this.getalluser();
    },(error:any)=>{
     if(error.status==500){
      alert("internal server error customer are not deleted because customer are added product in cart ");
     }
    })

  }


}
