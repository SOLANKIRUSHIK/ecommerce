import { Component } from '@angular/core';
import { Route, Router, RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-user-dashboard',
  imports: [RouterOutlet,RouterLink],
  templateUrl: './user-dashboard.component.html',
  styleUrl: './user-dashboard.component.css'
})
export class UserDashboardComponent {


  
    constructor(private router: Router) {}
  
    ngOnInit(): void {
  
    }
  
   
    logout() {
      sessionStorage.removeItem('key');
      this.router.navigateByUrl('Login'); 
    }
}
