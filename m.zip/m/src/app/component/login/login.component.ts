import { Component, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule,RouterLink,CommonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  http = inject(HttpClient);
  route = inject(Router);

  loginform: FormGroup = new FormGroup({
    Email: new FormControl("", [Validators.required, Validators.pattern(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,6}$/)]),
    Password: new FormControl("", [Validators.required]),
    Role: new FormControl("User")
  });

  submitform() {
    const role = this.loginform.value.Role;
    const formdata = new FormData();
    formdata.append("Email", this.loginform.value.Email);
    formdata.append("Password", this.loginform.value.Password);

    if (role === "Admin") {
     
      if (this.loginform.value.Email === "admin@gmail.com" && this.loginform.value.Password === "123") {
        alert("Login successful as Admin");
        sessionStorage.setItem("key", 'Admin');
        this.route.navigateByUrl("Admindashboard");
      } else {
        alert("Invalid credentials");
      }
    } else {
     
      this.http.post('https://localhost:7235/api/Customer/Login', formdata).subscribe(
        (res: any) => {
          alert(res.message);
          sessionStorage.setItem("key", JSON.stringify(res.id));
          this.route.navigateByUrl("UserDashboard");
        },
        (error: any) => {
          if (error.status === 401) {
            alert('Invalid credentials. Please try again.');
          } else if (error.status === 500) {
            alert('Server error. Please try again later.');
          } else {
            console.error(error);
            alert('An unexpected error occurred.');
          }
        }
      );
    }
  }
}
