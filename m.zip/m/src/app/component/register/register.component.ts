import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AdminserviceService } from '../../Service/adminservice.service';
import { LoginComponent } from '../login/login.component';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule,CommonModule ,RouterLink],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {


http=inject(HttpClient);
constructor(private admim:AdminserviceService){}


registrationform:FormGroup=new FormGroup({

  Name:new FormControl("",[Validators.required,Validators.minLength(3)]),
  Email :new FormControl("",[Validators.required,Validators.pattern(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,6}$/)]),
  Password:new FormControl("",[Validators.required]),
  contactNumber:new FormControl("",[Validators.pattern(/^[0-9]{10}$/),Validators.required]),
  Address:new FormControl("",[Validators.required])


});


submitform(){
  
  const formdata=new FormData();
  formdata.append("Name",this.registrationform.value.Name);
  formdata.append("Email",this.registrationform.value.Email);
  formdata.append("Password",this.registrationform.value.Password);
  formdata.append("contactNumber",this.registrationform.value.contactNumber);
  formdata.append("Address",this.registrationform.value.Address);


this.admim.registration(formdata).subscribe((res:any)=>{

  alert(res.message);
  this.registrationform.reset();
},(error:any)=>{
 alert(error.message);
})


}



}
