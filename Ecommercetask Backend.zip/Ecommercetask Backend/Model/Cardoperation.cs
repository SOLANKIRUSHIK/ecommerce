﻿namespace Ecommercetask.Model
{
    public class Cardoperation
    {
        
        public int Id { get; set; }

        public int Quantity {  get; set; }

        public string Actiontype { get; set; }
    }
}
