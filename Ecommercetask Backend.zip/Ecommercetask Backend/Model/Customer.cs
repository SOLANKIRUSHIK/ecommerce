﻿using System.ComponentModel.DataAnnotations;

namespace Ecommercetask.Model
{
    public class Customer
    {

        public int Id { get; set; }

        [Required]
        [MaxLength(255)]
        public string Name { get; set; }

        [EmailAddress(ErrorMessage = "Invalid email address format.")]
        [Required]
        public string Email { get; set; }

        [Required]
        public string Password {  get; set; }

        [Required]
        public string contactNumber { get; set; }

        [Required, MaxLength(255)]
        public string Address {  get; set; }

    }
}
