﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Ecommercetask.Model
{
    public class CartDTO
    {
        //from cart id
        public int Id { get; set; }

        public int Quantity { get; set; }

        public decimal Totalamount { get; set; }


        public string Name { get; set; }

        public string Productname { get; set; }

        public string Productdescription { get; set; }

        public decimal Productprice { get; set; }

        public string Productcategory { get; set; }

        public string? Productimageurl { get; set; }


    }
}
