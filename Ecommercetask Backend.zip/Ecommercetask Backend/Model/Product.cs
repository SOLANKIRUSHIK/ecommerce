﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Ecommercetask.Model
{
    public class Product
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Productname { get; set; }

        [Required]
        [MaxLength(200)]
        public string Productdescription { get; set; }

        [Required]
        public decimal Productprice { get; set; }

        [Required]
        public int Productquantity {  get; set; }

        [Required]
        public  string Productcategory {  get; set; }

        public string? Productimageurl {  get; set; }

        [NotMapped]

        public IFormFile Productimage { get; set; }
    }
}
