﻿using System.Data;
using Ecommercetask.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using PdfSharpCore;
using PdfSharpCore.Pdf;
using TheArtOfDev.HtmlRenderer.PdfSharp;

namespace Ecommercetask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {

        private readonly string connectionstring = "Server=(localdb)\\MSSQLLocalDB;Database=Ecommercetask;Trusted_Connection=True;TrustServerCertificate=True;";

        [HttpPost("Addtocart")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult Addtocartproduct([FromForm] Cart cart) { 
        
            SqlConnection conn=new SqlConnection(connectionstring);

            try
            {
                SqlCommand cmd = new SqlCommand("inserintocart", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CustomerId", cart.CustomerId);
                cmd.Parameters.AddWithValue("@ProductId", cart.ProductId);
                cmd.Parameters.AddWithValue("@Quantity", cart.Quantity);
                cmd.Parameters.AddWithValue("@Totalamount", cart.Totalamount);


                SqlParameter @Isavailable = new SqlParameter("@Isavailable", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                cmd.Parameters.Add(@Isavailable);

                conn.Open();

                cmd.ExecuteNonQuery();

                int result = Convert.ToInt32(@Isavailable.Value);

                if (result==1)
                {
                    return Ok(new { message = "Already Added in cart " });

                }
                else
                {
                    return Ok(new { message = "Successfully added in cart" });
                }





            }
            catch (Exception ex) {

                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
            finally
            {
                conn.Close();
                conn.Dispose();

            }
        
        
        }

        [HttpGet("getcartdata/{id:int}")]

        public ActionResult<IEnumerable<CartDTO>> getalldetail([FromRoute]int id)
        {
            List<CartDTO> cartitem = new List<CartDTO>();

            SqlConnection conn = new SqlConnection(connectionstring);

            try
            {
                SqlCommand cmd = new SqlCommand("Getcartdetail", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", id);

                conn.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    var itemcart = new CartDTO
                    {
                        Id = reader.GetInt32(0),
                        Quantity=reader.GetInt32(1),
                        Totalamount=reader.GetDecimal(2),
                        Name=reader.GetString(3),
                        Productname=reader.GetString(4),
                        Productdescription=reader.GetString(5),
                        Productprice=reader.GetDecimal(6),
                        Productcategory=reader.GetString(7),
                        Productimageurl=reader.GetString(8)


                    };

                    cartitem.Add(itemcart);

                }

                var result=cartitem.Select(item => new
                {
                    item.Id,
                    item.Quantity,
                    item.Totalamount,
                    item.Name,
                    item.Productname,
                    item.Productdescription,
                    item.Productprice,
                    item.Productcategory,
                    Productimageurl = $"{Request.Scheme}:/{Request.Host}/Upload/{item.Productimageurl}"
                });

                if (result !=null)
                {
                    return Ok(result);

                }
                else
                {
                    return NotFound(new { message = "no item available inside the cart " });
                }


            }
            catch(Exception ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
            finally
            {
                conn.Close();
                conn.Dispose();

            }


        }



        [HttpPost("Operation")]
        public IActionResult Operationoncart([FromForm] Cardoperation operation)
        {
            SqlConnection conn = new SqlConnection(connectionstring);

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("AddToCart", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CartId", operation.Id);
                cmd.Parameters.AddWithValue("@Quantity", operation.Quantity);
                cmd.Parameters.AddWithValue("@ActionType", operation.Actiontype);

            
                SqlParameter ispara = new SqlParameter("@Isavailable", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output,
                };
                cmd.Parameters.Add(ispara);
                cmd.ExecuteNonQuery();

                int result = Convert.ToInt32(ispara.Value);

               
                if (operation.Actiontype == "ADD")
                {
                    if (result == 0)
                    {
                        return Ok(new { message = "Product is out of stock." });
                    }
                    else
                    {
                        return Ok(new { message = "Product added to the cart." });
                    }
                }
                else if (operation.Actiontype == "REMOVE")
                {
                    if (result == 0)
                    {
                        return Ok(new { message = "Product could not be removed from the cart due to insufficient quantity." });
                    }
                    else
                    {
                        return Ok(new { message = "Product removed from the cart." });
                    }
                }
                else
                {
                    return BadRequest(new { message = "Invalid action type." });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }





        [HttpGet("Gettotle/{id}")]

        public IActionResult Gettotle([FromRoute]int id)
        {
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                SqlCommand cmd = new SqlCommand("gettotle", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                decimal result = Convert.ToDecimal( cmd.ExecuteScalar());

                if (result!=null)
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound();
                }


            }catch(Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
            finally
            {

                conn.Close();
                conn.Dispose();
            }
        }



        [HttpDelete("removefromcard/{id:int}")]

        public IActionResult Deletefromcardbyid([FromRoute] int id)
        {

            SqlConnection conn = new SqlConnection(connectionstring);

            try
            {
                SqlCommand cmd = new SqlCommand("Deletefromcart", conn);
                cmd.CommandType= CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("id", id);
                conn.Open();

                int row=cmd.ExecuteNonQuery();

                if (row > 0) {

                    return Ok(new { message = "Remove from cart" });
                }
                else
                {
                    return NotFound("not fount item in cart");
                }

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);

            }
            finally
            {
                conn.Close();
                conn.Dispose();


            }
        }


        [HttpGet("generatepdf/{id:int}")]
        public IActionResult Pdfgenerate([FromRoute] int id)
        {
            List<CartDTO> cartitem = new List<CartDTO>();

            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                try
                {
                    var document = new PdfDocument();
                    string htmlcontent = "<h1>Items Available in Cart</h1>";
                    htmlcontent += "<table border='1' style='border-collapse: collapse;'>" +
                        "<thead>" +
                        "<tr>" +
                        "<th>Cart Id</th>" +
                        "<th>Quantity</th>" +
                        "<th>Total Amount</th>" +
                        "<th>Customer Name</th>" +
                        "<th>Product Name</th>" +
                        "<th>Product Description</th>" +
                        "<th>Product Price</th>" +
                        "<th>Product Category</th>" +
                        "<th>Image</th>" +
                        "</tr></thead>" +
                        "<tbody>";

                    SqlCommand cmd = new SqlCommand("Getcartdetail", conn)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.AddWithValue("@Id", id);

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        htmlcontent += $"<tr>" +
                            $"<td>{reader.GetInt32(0)}</td>" +
                            $"<td>{reader.GetInt32(1)}</td>" +
                            $"<td>{reader.GetDecimal(2):C}</td>" +
                            $"<td>{reader.GetString(3)}</td>" +
                            $"<td>{reader.GetString(4)}</td>" +
                            $"<td>{reader.GetString(5)}</td>" +
                            $"<td>{reader.GetDecimal(6):C}</td>" +
                            $"<td>{reader.GetString(7)}</td>" +
                            $"<td><img src='{Request.Scheme}://{Request.Host}/Upload/{reader.GetString(8)}' alt='Image' style='width:100px;'></td>" +
                            $"</tr>";
                    }
                    reader.Close();

                    htmlcontent += "</tbody></table>";

                    SqlCommand cmd2 = new SqlCommand("gettotle", conn);
                    cmd2.CommandType = CommandType.StoredProcedure;
                    cmd2.Parameters.AddWithValue("@id", id);
               
                    decimal result = Convert.ToDecimal(cmd2.ExecuteScalar());

                    htmlcontent += "<h1>Total amount= "+result+"</h1>";


                    PdfGenerator.AddPdfPages(document, htmlcontent, PageSize.A4);

                    byte[] response;

                    using (MemoryStream stream = new MemoryStream())
                    {
                        document.Save(stream);
                        response = stream.ToArray();
                    }

                    string filename = "Customer_" + id + ".pdf";
                    return File(response, "application/pdf", filename);
                }
                catch (Exception ex)
                {
                    
                    Console.WriteLine($"Error generating PDF: {ex.Message}");
                    return StatusCode(500, "Internal Server Error");
                }
               
            }
        }




    }
}
