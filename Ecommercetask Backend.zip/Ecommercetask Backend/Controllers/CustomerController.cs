﻿using System.Data;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using Ecommercetask.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace Ecommercetask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly string connectonstring = "Server=(localdb)\\MSSQLLocalDB;Database=Ecommercetask;Trusted_Connection=True;TrustServerCertificate=True;";
        private readonly IConfiguration configuration;

        public CustomerController(IConfiguration configuration)
        {
            this.configuration = configuration;
        }




        [HttpPost("Register")]

        public IActionResult RegsterCustomer([FromForm] Customer customer)
        {
            SqlConnection conn=new SqlConnection(connectonstring);

            try
            {

                SqlCommand cmd = new SqlCommand("Registercustomer", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@Name", customer.Name);
                cmd.Parameters.AddWithValue("@Email", customer.Email);
                cmd.Parameters.AddWithValue("@Password", customer.Password);
                cmd.Parameters.AddWithValue("@contactNumber", customer.contactNumber);
                cmd.Parameters.AddWithValue("@Address", customer.Address);

                SqlParameter message = new SqlParameter("@Message", SqlDbType.VarChar, 255)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(message);

                conn.Open();
                cmd.ExecuteNonQuery();

                string resultMessage = message.Value.ToString();

                if (resultMessage == "registered successfully.")
                {
                    return Ok(new {message= resultMessage });
                }
                else if (resultMessage == "Email already exists.")
                {
                    return Ok(new { message = resultMessage });
                }
                else
                {
                    return BadRequest(new { message = "An error occurred during registration." });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,ex.Message);
            }
            finally { 
            
                conn.Close();
                conn.Dispose();
            
            
            }



        }

        [HttpPost("Login")]
        public ActionResult<Customer> Logincustomer([FromForm] Login login)
        {
            SqlConnection conn = new SqlConnection(connectonstring);

            try
            {
                SqlCommand cmd = new SqlCommand("Logincustomer", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Email", login.Email);
                cmd.Parameters.AddWithValue("@Password", login.Password);

                SqlParameter idpara = new SqlParameter("@Id", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                cmd.Parameters.Add(idpara);

                conn.Open();

                cmd.ExecuteNonQuery();

                int result = Convert.ToInt32(idpara.Value);  

                if (result > 0)
                {
                   
                    return Ok(new {message="Login successfully" ,Id = result });
                }
                else
                {
                    return Unauthorized("Invalid credentials.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred during login", details = ex.Message });
            }
            finally
            {
                conn.Close();
            }
        }



        [HttpDelete("Deletecustomer/{id:int}")]

        public IActionResult Deletecustomerbyid([FromRoute]int id)
        {
            SqlConnection conn = new SqlConnection(connectonstring);
            try
            {
                SqlCommand cmd = new SqlCommand("DeleteUser", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                int row = cmd.ExecuteNonQuery();

                if (row > 0)
                {
                    return Ok(new { message = "delete user successfully" });

                }
                else
                {
                    return NotFound(new {message="User not deleted"});
                }

            }catch(Exception ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError);
            }
            finally
            {
                conn.Close();
                conn.Dispose();

            }

        }



        [HttpGet("GetCustomerByid/{id:int}")]

        public ActionResult<Customer> GetcustomerByid([FromRoute] int id)
        {

            SqlConnection conn = new SqlConnection(connectonstring);
            try
            {
                SqlCommand cmd = new SqlCommand("GetUserByid", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    Customer c = new Customer
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Email = reader.GetString(2),
                        Password = reader.GetString(3),
                        contactNumber = reader.GetString(4),
                        Address = reader.GetString(5)
                    };


                    return Ok(c);
                }
                else
                {
                    return NotFound();
                }
                



            }catch(Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);

            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }


        [HttpPut("UpdateCustomer")]
        public IActionResult Updateuserdata([FromForm] Customer customer)
        {
            SqlConnection conn = new SqlConnection(connectonstring);
            try
            {
                SqlCommand cmd = new SqlCommand("Updateuser", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", customer.Id);
                cmd.Parameters.AddWithValue("@Name", customer.Name);
                cmd.Parameters.AddWithValue("@Email", customer.Email);
                cmd.Parameters.AddWithValue("@Password", customer.Password);
                cmd.Parameters.AddWithValue("@contactNumber", customer.contactNumber);
                cmd.Parameters.AddWithValue("@Address", customer.Address);
                conn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                {
                    return Ok(new { message = "Update user Successfully" });
                }
                else
                {
                    return NotFound(new {message="user with this id are not available"});
                }


            }catch(Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
            finally
            {
                conn.Close();
                conn.Dispose();

            }
        }




    }
}
