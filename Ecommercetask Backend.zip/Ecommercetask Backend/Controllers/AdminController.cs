﻿using System.Data;
using Ecommercetask.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace Ecommercetask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {


        private readonly  string connectonstring= "Server=(localdb)\\MSSQLLocalDB;Database=Ecommercetask;Trusted_Connection=True;TrustServerCertificate=True;";



        [HttpPost("AddProduct")]


        public IActionResult AddProduct([FromForm] Product product)
        {
            SqlConnection conn=new SqlConnection(connectonstring);

            try
            {
                
                if (product.Productimage != null) {

                    var path = Path.Combine(Directory.GetCurrentDirectory(), "Upload");

                    if (!Directory.Exists(path)) { 
                    Directory.CreateDirectory(path);
                    }

                    var filepath=Path.Combine(path,$"{Guid.NewGuid()}{Path.GetFileName(product.Productimage.FileName)}");


                    using (var s = new FileStream(filepath, FileMode.Create)) { 
                    
                            product.Productimage.CopyTo(s);
                    }

                    product.Productimageurl=Path.GetFileName(filepath);



                }
                else
                {
                    return BadRequest(new { message = "image is required" });
                }


                SqlCommand cmd = new SqlCommand("Addproduct", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Productname", product.Productname);
                cmd.Parameters.AddWithValue("@Productdescription", product.Productdescription);
                cmd.Parameters.AddWithValue("@Productprice", product.Productprice);
                cmd.Parameters.AddWithValue("@Productquantity", product.Productquantity);
                cmd.Parameters.AddWithValue("@Productcategory", product.Productcategory);
                cmd.Parameters.AddWithValue("@Productimageurl",product.Productimageurl);

                conn.Open();
               
                int row=cmd.ExecuteNonQuery();

                if (row > 0) {

                    return Ok(new { message = $"record added with number of row affected : {row}" });


                }
                else
                {
                    return BadRequest(new { message = "product are not added " });
                }


            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }



        }


        [HttpGet("GetAllProduct")]

        public ActionResult<IEnumerable<Product>> GetAllProduct()
        {
            List<Product> listproduct = new List<Product>();

            SqlConnection conn = new SqlConnection(connectonstring);

            try
            {
                SqlCommand cmd = new SqlCommand("Getallproduct", conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    var item = new Product
                    {
                        Id = reader.GetInt32(0),
                        Productname=reader.GetString(1),
                        Productdescription=reader.GetString(2),
                        Productprice = reader.GetDecimal(3),
                        Productquantity=reader.GetInt32(4),
                        Productcategory=reader.GetString(5),
                        Productimageurl=reader.GetString(6)


                    };
                    listproduct.Add(item);
                    
                }
                var result = listproduct.Select(item => new
                {
                    item.Id,
                    item.Productname,
                    item.Productdescription,
                    item.Productprice,
                    item.Productquantity,
                    item.Productcategory,
                    Productimageurl = $"{Request.Scheme}:/{Request.Host}/Upload/{item.Productimageurl}"
                });
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }



        }


        [HttpDelete("DelteProduct/{id:int}")]

        public IActionResult DeleteProduct([FromRoute] int id)
        {
            SqlConnection conn = new SqlConnection(connectonstring);

            try
            {
                SqlCommand idcmd = new SqlCommand("GetProductbyid", conn);
                idcmd.CommandType = CommandType.StoredProcedure;
                idcmd.Parameters.AddWithValue("@ID", id);

                SqlParameter outputImageUrl = new SqlParameter("@Productimageurl", SqlDbType.VarChar, 255);
                outputImageUrl.Direction = ParameterDirection.Output;
                idcmd.Parameters.Add(outputImageUrl);

                conn.Open();

          
                idcmd.ExecuteNonQuery();

                string Productimageurl = outputImageUrl.Value?.ToString();


                if (!string.IsNullOrEmpty(Productimageurl))
                {
                    var imagepath = Path.Combine(Directory.GetCurrentDirectory(), "Upload", Productimageurl);

                    if (System.IO.File.Exists(imagepath))
                    {
                        System.IO.File.Delete(imagepath);
                    }




                    SqlCommand cmd = new SqlCommand("DeleteProduct", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Id", id);
                   
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)
                    {
                        return Ok(new { message = $"Product deleted succesfully with number of row affected : {row}" });
                    }
                    else
                    {
                        return BadRequest("record not found");
                    }

                }
                else
                {
                    return NotFound(new { message = $"Product with this id not found :{id} " });
                }


            }
            catch(Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);

            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }



        }
        [HttpGet("GetAllUser")]
        public ActionResult<IEnumerable<CustomerDTO>> GetAllUser()
        {
            List<CustomerDTO> listcust = new List<CustomerDTO>();

              SqlConnection conn = new SqlConnection(connectonstring);
            try
            {                              
                    conn.Open();

                SqlCommand cmd = new SqlCommand("GetAllCustomer", conn);
                    
                        cmd.CommandType = CommandType.StoredProcedure;


                SqlDataReader reader = cmd.ExecuteReader();
                        
                           
                            while (reader.Read())
                            {
                                var user = new CustomerDTO
                                {
                                    Id = reader.GetInt32(0),               
                                    Name = reader.GetString(1),           
                                    Email = reader.GetString(2),           
                                    contactNumber = reader.GetString(3),   
                                    Address = reader.GetString(4)          
                                };

                                listcust.Add(user);
                                                                       
                }

                return Ok(listcust);  
            }
            catch (Exception ex)
            {
               
                return StatusCode(500, "Internal server error: " + ex.Message);
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }



    }
}
