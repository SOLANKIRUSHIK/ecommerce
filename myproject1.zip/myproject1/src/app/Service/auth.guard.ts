import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {

  const loggeduser=sessionStorage.getItem("key");
  const  router=inject(Router);

  if(loggeduser !=null){

    return true;
  }else{
    router.navigateByUrl("Login");
    return false;
  }


};
