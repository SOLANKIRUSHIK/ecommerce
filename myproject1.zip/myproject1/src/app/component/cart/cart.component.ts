import { CommonModule, JsonPipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart',
  imports: [CommonModule],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent implements OnInit {

  cartlist: any[] = [];
  totleamount: number = 0;
  newQuantity: number = 1;
  http = inject(HttpClient);


  
  alertMessage:string='';
  alertType:string='';
  alertshow:boolean=false;


  customerid: number = JSON.parse(sessionStorage.getItem("key") || "null");
  ngOnInit(): void {

    this.getallproductfromcart();
    this.gettotlemount();
  }



  getallproductfromcart() {
    this.alertshow=false;
    if (this.customerid != null) {
      this.http.get("https://localhost:7235/api/Cart/getcartdata/" + this.customerid).subscribe((res: any) => {
        this.cartlist = res;
      }, (error: any) => {
        // alert(error.message);
        this.alertMessage=error.message;
        this.alertType='danger';
        this.alertshow=true;
      })
    }
  }
  gettotlemount() {
    this.alertshow=false;
    if (this.customerid != null) {
      this.http.get("https://localhost:7235/api/Cart/Gettotle/" + this.customerid).subscribe((res: any) => {
        this.totleamount = res;
      }, (error: any) => {
        // alert(error.message);
        this.alertMessage=error.message;
        this.alertType='danger';
        this.alertshow=true;
      })
    }
  }

  removefromcart(id: number) {
    this.alertshow=false;
    this.http.delete(`https://localhost:7235/api/Cart/removefromcard/${id}`).subscribe((result: any) => {
      // alert(result.message);
      this.alertMessage=result.message;
      this.alertType='info';
      this.alertshow=true;

      setTimeout(() => {
        this.getallproductfromcart();
        this.gettotlemount();
      }, 1000);

    }, (error: any) => {

      // alert(error.message);
      this.alertMessage=error.message;
      this.alertType='danger';
      this.alertshow=true;
    })
  }

  operationoncart(id: number, action: string) {


    this.alertshow=false;
    var formdata = new FormData();
    formdata.append("Id", id.toString());
    formdata.append("Quantity", this.newQuantity.toString());
    formdata.append("Actiontype", action);


    this.http.post("https://localhost:7235/api/Cart/Operation", formdata).subscribe((res: any) => {
      // alert(res.message);


      if(res.message=="Product is out of stock."){
        this.alertMessage=res.message;
        this.alertType='info';
    
      }else if(res.message=="Product added to the cart."){
        this.alertMessage=res.message;
        this.alertType='success';
        
      }else if(res.message=="Product could not be removed from the cart due to insufficient quantity."){
        this.alertMessage=res.message;
        this.alertType='warning';
     
      }else if(res.message=="Product removed from the cart."){
        this.alertMessage=res.message;
        this.alertType='danger';
      
      }else if(res.message=="Invalid action type."){
        this.alertMessage=res.message;
        this.alertType='danger';
     
      }else{
        this.alertMessage=res.message;
        this.alertType='danger';
      }
      this.alertshow=true;
      setTimeout(() => {
        this.getallproductfromcart();
        this.gettotlemount();
      }, 1000);
      // this.getallproductfromcart();
      // this.gettotlemount();
    }, (error: any) => {
      alert(error.message);
    })


  }


  download() {
    window.location.href = `https://localhost:7235/api/Cart/generatepdf/${this.customerid}`;
  }


  hideAlert(){
    this.alertshow=false;
  }

}
