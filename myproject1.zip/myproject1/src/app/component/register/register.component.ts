import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AdminserviceService } from '../../Service/adminservice.service';
import { LoginComponent } from '../login/login.component';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule,CommonModule ,RouterLink],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  alertMessage:string='';
  alertType:string='';
  alertshow:boolean=false;





http=inject(HttpClient);
route=inject(Router);
constructor(private admim:AdminserviceService){}


registrationform:FormGroup=new FormGroup({

  Name:new FormControl("",[Validators.required,Validators.minLength(3)]),
  Email :new FormControl("",[Validators.required,Validators.pattern(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,6}$/)]),
  Password:new FormControl("",[Validators.required]),
  contactNumber:new FormControl("",[Validators.pattern(/^[0-9]{10}$/),Validators.required]),
  Address:new FormControl("",[Validators.required])


});


submitform(){
  this.alertshow=false;
  const formdata=new FormData();
  formdata.append("Name",this.registrationform.value.Name);
  formdata.append("Email",this.registrationform.value.Email);
  formdata.append("Password",this.registrationform.value.Password);
  formdata.append("contactNumber",this.registrationform.value.contactNumber);
  formdata.append("Address",this.registrationform.value.Address);


this.admim.registration(formdata).subscribe((res:any)=>{

  // alert(res.message);
  if(res.message=="registered successfully."){
    this.alertMessage="registered successfully.";
    this.alertType='success';
    this.alertshow=true;

    setTimeout(() => {
      this.route.navigateByUrl('Login');
    }, 1000);
  }else if(res.message=="Email already exists."){
    this.alertMessage="Email already exists.";
    this.alertType='warning';
    this.alertshow=true;
  }else{
    this.alertMessage=res.message;
    this.alertType='danger';
    this.alertshow=true;
  }
  // this.registrationform.reset();
},(error:any)=>{
 alert(error.message);
})


}

hideAlert(){
this.alertshow=false;
}

}
