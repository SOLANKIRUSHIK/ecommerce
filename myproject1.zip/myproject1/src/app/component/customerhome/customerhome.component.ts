import { Component, inject } from '@angular/core';
import { Iproduct } from '../../Model/Interface/Product';
import { AdminserviceService } from '../../Service/adminservice.service';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-customerhome',
  imports: [CommonModule],
  templateUrl: './customerhome.component.html',
  styleUrls: ['./customerhome.component.css'] 
  
})
export class CustomerhomeComponent {

  productlist: Iproduct[] = [];
  loggeduserid: any = null;
  totlepages:number=0;
  currentpage:number=1;
  pagesize:number=10;


  
  
  alertMessage:string='';
  alertType:string='';
  alertshow:boolean=false;
 
  http=inject(HttpClient);

  constructor(private admin: AdminserviceService) {}
  
  ngOnInit(): void {
    // this.getproduct();
    this.fetchproduct();
    this.loggeduserid=JSON.parse(sessionStorage.getItem("key")||"null");
  
  }

  // getproduct() {
  //   this.admin.getAllproduct().subscribe(
  //     (res: any) => {
  //       this.productlist = res;
  //     },
  //     (error: any) => {
  //       console.error('Error fetching products', error);
  //       alert(error.message);
  //     }
  //   );
  // }

  
  fetchproduct(){
    this.alertshow=false;
    this.http.get(`https://localhost:7235/api/Pagination?page=${this.currentpage}&pageSize=${this.pagesize}`).subscribe((res:any)=>{

      this.productlist=res.data;
      this.totlepages=res.totlepages;
    },(error:any)=>{
      this.alertMessage=error.message;
      this.alertType='danger';
      this.alertshow=true;
    })
  }

  goto(page:number){
    if(page>=1&&page<=this.totlepages){
      this.currentpage=page;
      this.fetchproduct();
    }
  }

  AddToCart(id: number, totalPrice: number) {
   
   this.alertshow=false;
    const quantity = 1;
    if(this.loggeduserid!=null){
    
      const formdata=new FormData();
      formdata.append("CustomerId",this.loggeduserid);
      formdata.append("ProductId",id.toString());
      formdata.append("Quantity",quantity.toString());
      formdata.append("Totalamount",totalPrice.toString());

      this.admin.Addtocart(formdata).subscribe((res:any)=>{

        // alert(res.message);
        if(res.message=="Already Added in cart "){
          this.alertMessage=res.message;
          this.alertType='warning';
        }else {
          this.alertMessage=res.message;
          this.alertType='success';
        }
        this.alertshow=true;

        // this.getproduct();
      },(error:any)=>{
        // alert(error.message);
        this.alertMessage=error.message;
        this.alertType='danger';
        this.alertshow=true;

      })



    }
  }

  hideAlert(){
    this.alertshow=false;
  }


}
