import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { AdminserviceService } from '../../Service/adminservice.service';
import { Iproduct } from '../../Model/Interface/Product';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-adminproduct',
  imports: [CommonModule],
  templateUrl: './adminproduct.component.html',
  styleUrl: './adminproduct.component.css'
})
export class AdminproductComponent implements OnInit {



  productlist:Iproduct[]=[];

  totalPages: number = 0;
  currentPage: number = 1;

  pageSize: number = 10;


  
  alertMessage:string='';
  alertType:string='';
  alertshow:boolean=false;
  
constructor(private admin:AdminserviceService){

}

http=inject(HttpClient);

  ngOnInit(): void {
    // this.getproduct();
    this.fetchproduct()

  }

// getproduct(){
//  this.admin.getAllproduct().subscribe((res:any)=>{
//     debugger;
//     this.productlist=res;
//   },(error: any) => {
//     debugger;
//     console.error('Error fetching products', error);
//   alert(error.message);
//   });
// };

fetchproduct(){
  this.alertshow=false;
  this.http.get(`https://localhost:7235/api/Pagination?page=${this.currentPage}&pageSize=${this.pageSize}`).subscribe((res:any)=>{

    if(res.totlepages==0){
      this.currentPage=1;
      this.fetchproduct();
    }else{


      this.productlist=res.data;
      this.totalPages=res.totlepages;  
    }
  },(error:any)=>{
    // alert(error.message);
    this.alertMessage=error.message;
  this.alertType='success';
  this.alertshow=true;
  })
}

goToPage(page: number) {
  if (page >= 1 && page <= this.totalPages) {
    this.currentPage = page;
    this.fetchproduct();
  }
}




deleteProduct(id:number){
debugger;
this.alertshow=false;
this.admin.deleteproductById(id).subscribe((result:any)=>{
  // alert(result.message);
  this.alertMessage=result.message;
  this.alertType='success';
  this.alertshow=true;
  // this.getproduct();
  setTimeout(() => {
    
    this.fetchproduct();
  }, 3000);
},(error:any)=>{

  // alert(error.message);
  this.alertMessage=error.message;
  this.alertType='danger';
  this.alertshow=true;
})

}

hideAlert(){
  this.alertshow=false;
}




}





