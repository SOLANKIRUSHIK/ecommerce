import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-user',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {

  customerid: string = "";
  
  
  alertMessage:string='';
  alertType:string='';
  alertshow:boolean=false;

  ngOnInit(): void {
    this.customerid = sessionStorage.getItem("key")||"null";
   this.getUserdata();
  }

  route = inject(Router);

  constructor(private http: HttpClient) { }

  getUserdata() {
    this.alertshow=false;
    this.http.get("https://localhost:7235/api/Customer/GetCustomerByid/" + this.customerid).subscribe((res: any) => {
 
      this.registrationform.setValue({
        Name:  res.name,
        Email: res.email,
        Password: res.password ,
        contactNumber: res.contactNumber,
        Address: res.address
      });
    }, (error: any) => {
      // alert("Error fetching data: " + error.message);
      this.alertMessage="Error fetching data:"+error.message;
      this.alertType='danger';
      this.alertshow=true;
    });
  }

  registrationform: FormGroup = new FormGroup({
    Name: new FormControl("", [Validators.required, Validators.minLength(3)]),
    Email: new FormControl("", [Validators.required, Validators.pattern(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,6}$/)]),
    Password: new FormControl("", [Validators.required]),
    contactNumber: new FormControl("", [Validators.pattern(/^[0-9]{10}$/), Validators.required]),
    Address: new FormControl("", [Validators.required])
  });

  submitform() {
    this.alertshow=false;
    const formdata = new FormData();
    formdata.append("Name", this.registrationform.value.Name);
    formdata.append("Email", this.registrationform.value.Email);
    formdata.append("Password", this.registrationform.value.Password);
    formdata.append("contactNumber", this.registrationform.value.contactNumber);
    formdata.append("Address", this.registrationform.value.Address);
    formdata.append("Id", this.customerid);

    this.http.put("https://localhost:7235/api/Customer/UpdateCustomer", formdata).subscribe(
      (res: any) => {
        // alert(res.message);
        this.alertMessage=res.message;
        this.alertType='success';
        this.alertshow=true;
        setTimeout(() => {
          
          this.route.navigateByUrl("/UserDashboard/Home");
        }, 3000);
      },
      (error: any) => {
        // alert("An error occurred: " + error.message);
        this.alertMessage=error.message;
        this.alertType='danger';
        this.alertshow=true;
      }
    );
  }


  hideAlert(){
    this.alertshow=false;
  }
}
