import { Component, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule,RouterLink,CommonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  alertMessage:string='';
  alertType:string='';
  alertshow:boolean=false;



  http = inject(HttpClient);
  route = inject(Router);

  loginform: FormGroup = new FormGroup({
    Email: new FormControl("", [Validators.required, Validators.pattern(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,6}$/)]),
    Password: new FormControl("", [Validators.required]),
    Role: new FormControl("User")
  });

  submitform() {
    const role = this.loginform.value.Role;
    const formdata = new FormData();
    formdata.append("Email", this.loginform.value.Email);
    formdata.append("Password", this.loginform.value.Password);
      this.alertshow=false;
    if (role === "Admin") {
     
      if (this.loginform.value.Email === "admin@gmail.com" && this.loginform.value.Password === "123") {
     
        this.alertMessage="Login successful as Admin";
        this.alertType='success';
        this.alertshow=true;
        sessionStorage.setItem("key", 'Admin');
        setTimeout(() => {
          
          this.route.navigateByUrl("Admindashboard");
        }, 1000);
      } else {
       
        this.alertMessage="Invalid credentials";
        this.alertType='danger';
        this.alertshow=true;
      }
    } else {
     
      this.http.post('https://localhost:7235/api/Customer/Login', formdata).subscribe(
        (res: any) => {
          // alert(res.message);
          this.alertMessage="Login successful as User";
          this.alertType='success';
          this.alertshow=true;
          sessionStorage.setItem("key", JSON.stringify(res.id));
          setTimeout(() => {
          
            this.route.navigateByUrl("UserDashboard");
          }, 1000);
        },
        (error: any) => {
          if (error.status === 401) {
          
            this.alertMessage="Invalid credentials";
            this.alertType='danger';
            this.alertshow=true;
          } else if (error.status === 500) {
          
            this.alertMessage="Server error. Please try again later.";
            this.alertType='danger';
            this.alertshow=true;
          } else {
            console.error(error);
         
            this.alertMessage="An unexpected error occurred.";
            this.alertType='danger';
            this.alertshow=true;
          }
        }
      );
    }
  }


  hideAlert(){
    this.alertshow=false;
  }
}
