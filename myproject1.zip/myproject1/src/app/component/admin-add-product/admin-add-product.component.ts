import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, inject, ViewChild, viewChild } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AdminserviceService } from '../../Service/adminservice.service';

@Component({
  selector: 'app-admin-add-product',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './admin-add-product.component.html',
  styleUrl: './admin-add-product.component.css'
})
export class AdminAddProductComponent {

  alertMessage:string='';
  alertType:string='';
  alertshow:boolean=false;




  constructor(private admin: AdminserviceService) {

  }
  @ViewChild('file') fileinput: ElementRef | undefined;

  file: File | null = null;

  productform: FormGroup = new FormGroup({
    Productname: new FormControl("", [Validators.required, Validators.minLength(4)]),
    Productdescription: new FormControl("", [Validators.required]),
    Productprice: new FormControl("", [Validators.required]),
    Productquantity: new FormControl("", [Validators.required]),
    Productcategory: new FormControl("", [Validators.required]),
    productimage:new FormControl(null,[Validators.required])
  });


  submitimage(event: any) {
    debugger
    this.file = event.target.files[0];
  }


  submitform() {
    this.alertshow=false;
    if (!this.file) {
      alert("select valid file");
      return;
    } else {


      debugger;
      const formdata = new FormData();
      formdata.append("Productname", this.productform.value.Productname);
      formdata.append("Productdescription", this.productform.value.Productdescription);
      formdata.append("Productprice", this.productform.value.Productprice);
      formdata.append("Productquantity", this.productform.value.Productquantity);
      formdata.append("Productcategory", this.productform.value.Productcategory);
      formdata.append("Productimage", this.file);

      this.admin.addproduct(formdata).subscribe((result: any) => {

        // alert(result.message);
        this.alertMessage=result.message;
        this.alertType='success';
        this.alertshow=true;
        this.productform.reset();
        this.file = null;
        if (this.fileinput) {

          this.fileinput.nativeElement.value = '';
        }

      }, (error: any) => {
        if(error.status==400){
          // alert("only png and jpg file are allowed");
          this.alertMessage="only png and jpg file are allowed";
          this.alertType='warning';
          this.alertshow=true;
        }else{

          alert(error.message);
        }
      })



    }
  }

  hideAlert(){
    this.alertshow=false;
  }


}



