import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmingetalluserComponent } from './admingetalluser.component';

describe('AdmingetalluserComponent', () => {
  let component: AdmingetalluserComponent;
  let fixture: ComponentFixture<AdmingetalluserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdmingetalluserComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdmingetalluserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
