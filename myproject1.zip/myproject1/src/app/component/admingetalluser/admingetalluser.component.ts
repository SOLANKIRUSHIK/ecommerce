import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit } from '@angular/core';
import { AdminserviceService } from '../../Service/adminservice.service';
import { IUser } from '../../Model/Interface/Product';

@Component({
  selector: 'app-admingetalluser',
  imports: [CommonModule],
  templateUrl: './admingetalluser.component.html',
  styleUrl: './admingetalluser.component.css'
})
export class AdmingetalluserComponent implements OnInit {


  userlist: IUser[] = [];
  

  
  alertMessage:string='';
  alertType:string='';
  alertshow:boolean=false;

  constructor(private admin:AdminserviceService){

  }

  http = inject(HttpClient);

  ngOnInit(): void {
    this.getalluser();
  }


  getalluser() {
    this.alertshow=false;
    this.admin.getalluserInAdmin().subscribe((res: any) => {
      this.userlist = res;
    }, (error: any) => {
      // alert();
      this.alertMessage=error.message  ;
      this.alertType='danger';
      this.alertshow=true;
    })
  }

  deleteuser(id:number){
    this.alertshow=false;
   this.admin.deleteuserByIdInAdmin(id).subscribe((res:any)=>{

      // alert(res.message);
      this.alertMessage=res.message;
      this.alertType='success';
      this.alertshow=true;
      setTimeout(() => {
        
        this.getalluser();
      }, 1000);
    },(error:any)=>{
     if(error.status==500){
      // alert("internal server error customer are not deleted because customer are added product in cart ");
      this.alertMessage="internal server error customer are not deleted because customer are added product in cart ";
      this.alertType='danger';
      this.alertshow=true;
     }else{
      this.alertMessage=error.message;
      this.alertType='danger';
      this.alertshow=true;
     }
    })

  }


  hideAlert(){
    this.alertshow=false;
  }

}
