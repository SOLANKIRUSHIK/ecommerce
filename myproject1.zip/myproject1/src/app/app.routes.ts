import { Routes } from '@angular/router';
import { AdminproductComponent } from './component/adminproduct/adminproduct.component';
import { AdminAddProductComponent } from './component/admin-add-product/admin-add-product.component';
import { AdmingetalluserComponent } from './component/admingetalluser/admingetalluser.component';
import { RegisterComponent } from './component/register/register.component';
import { LoginComponent } from './component/login/login.component';
import { CustomerhomeComponent } from './component/customerhome/customerhome.component';
import { authGuard } from './Service/auth.guard';
import { AdminDashboardComponent } from './component/admin-dashboard/admin-dashboard.component';
import { UserDashboardComponent } from './component/user-dashboard/user-dashboard.component';
import { CartComponent } from './component/cart/cart.component';
import { UpdateUserComponent } from './component/update-user/update-user.component';

export const routes: Routes = [

    {
        path: '',
        redirectTo: 'register',
        pathMatch: 'full'
    },

    {
        path: 'register',
        component: RegisterComponent
    },
    {
        path: 'Login',
        component: LoginComponent
    },
    {
        path: 'UserDashboard',
        component: UserDashboardComponent,
        canActivate: [authGuard],
        children: [
            {
                path: '',
                redirectTo: 'Home',
                pathMatch: 'full'
            },
            {
                path: 'Home',
                component: CustomerhomeComponent
            },
            {
                path: 'Cart',
                component: CartComponent
            },
            {
                path:"UpdateUser",
                component:UpdateUserComponent

            }

        ]
    },
    {
        path: "Admindashboard",
        component: AdminDashboardComponent,
        canActivate: [authGuard],
        children: [
            {
                path: '',
                redirectTo: 'app-admin-add-product',
                pathMatch: 'full'
            },
            {
                path: 'app-adminproduct',
                component: AdminproductComponent
            },
            {
                path: 'app-admin-add-product',
                component: AdminAddProductComponent
            },
            {
                path: 'app-admingetalluser',
                component: AdmingetalluserComponent
            }
        ]

    },
    {
        path: '**',
        redirectTo: 'app-login'
    }
];
